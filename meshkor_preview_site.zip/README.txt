MeshKor — preview site
======================
Static, self-contained pages. No build step or server needed to view — open index.html.

Pages:
  index.html            Home
  builders.html         For builders (enroll, AINs, pricing)
  receivers.html        For receivers (validate incoming agents)
  how-it-works.html     The pedigree, sandbox, credential root
  programme.html        Trusted Bot Programme (AIN, trust ladder, audit)

Held in preview: every page carries <meta name="robots" content="noindex,nofollow">.
Remove that line on each page when you go live.

Waitlist: the form on index.html validates + confirms client-side only. To collect
emails, set the form's data-endpoint attribute to a POST URL (e.g. a Formspree endpoint).

build_site.py regenerates the four interior pages from index.html (shared CSS), so the
look can't drift. Run: python3 build_site.py

Domains: meshkor.ai (canonical); point .com and .net to it.
