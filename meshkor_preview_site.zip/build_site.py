#!/usr/bin/env python3
"""Generate the MeshKor site as self-contained pages sharing one CSS source.

Reads the master CSS out of index.html (so the interior pages can never drift
from the home page look), appends a few interior-only components, and writes
each interior page as a standalone HTML file with the CSS inlined.
"""
import re, pathlib

ROOT = pathlib.Path(__file__).parent
home = (ROOT / "index.html").read_text(encoding="utf-8")

def extract_div(html, needle):
    """Return the full <div>...</div> block whose opening tag contains `needle`,
    counting nested divs so we stop at the matching close, not the first one."""
    i = html.find(needle)
    if i == -1:
        return ""
    start = html.rfind("<div", 0, i)
    depth, j = 0, start
    while True:
        nxt_o = html.find("<div", j)
        nxt_c = html.find("</div>", j)
        if nxt_c == -1:
            return ""
        if nxt_o != -1 and nxt_o < nxt_c:
            depth += 1; j = nxt_o + 4
        else:
            depth -= 1; j = nxt_c + 6
            if depth == 0:
                return html[start:j]

# --- pull the master CSS from index.html ------------------------------------
m = re.search(r"<style>(.*?)</style>", home, re.S)
MASTER_CSS = m.group(1)

EXTRA_CSS = """
  /* ---- interior pages ---- */
  .page-hero{padding:64px 0 20px;border-top:none}
  .crumb{font-family:var(--mono);font-size:12px;color:var(--muted-2);letter-spacing:0.04em;margin-bottom:22px}
  .crumb a{color:var(--muted-2)}.crumb a:hover{color:var(--teal)}.crumb .sep{margin:0 8px;color:var(--line-strong)}
  .page-hero h1{font-size:clamp(32px,5vw,52px);font-weight:680;margin-top:16px;max-width:18ch}
  .page-hero .lede{font-size:clamp(17px,2.1vw,20px);color:var(--muted);max-width:60ch;margin-top:20px}
  .page-hero .hero-cta{margin-top:28px}
  .prose{max-width:66ch}
  .prose p{color:var(--muted);font-size:16.5px;margin-top:18px}
  .prose p:first-child{margin-top:0}
  .prose strong{color:var(--text);font-weight:600}
  .anchor{scroll-margin-top:84px}
  /* pricing tiers */
  .tiers{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:44px}
  @media(max-width:960px){.tiers{grid-template-columns:1fr 1fr}}
  @media(max-width:560px){.tiers{grid-template-columns:1fr}}
  .tier{background:linear-gradient(180deg,var(--panel-2),var(--panel));border:1px solid var(--line);border-radius:16px;padding:24px;display:flex;flex-direction:column}
  .tier.feature{border-color:rgba(79,209,197,0.45);box-shadow:0 20px 60px -30px rgba(79,209,197,0.4)}
  .tier .tname{font-family:var(--mono);font-size:12px;letter-spacing:0.12em;text-transform:uppercase;color:var(--teal)}
  .tier.feature .tname{color:var(--teal)}
  .tier .price{font-size:24px;font-weight:680;margin-top:14px;letter-spacing:-0.02em}
  .tier .price small{display:block;font-size:12px;font-weight:400;color:var(--muted-2);font-family:var(--mono);margin-top:4px;letter-spacing:0.02em}
  .tier p{color:var(--muted);font-size:14px;margin-top:14px;flex:1}
  .tier .cap{margin-top:16px;font-family:var(--mono);font-size:12px;color:var(--muted-2)}
  .tier .cap b{color:var(--text);font-weight:600}
  /* labeled prose rows */
  .rows{margin-top:40px;border-top:1px solid var(--line)}
  .row{display:grid;grid-template-columns:230px 1fr;gap:28px;padding:28px 0;border-bottom:1px solid var(--line)}
  @media(max-width:760px){.row{grid-template-columns:1fr;gap:10px}}
  .row .rlabel{font-family:var(--mono);font-size:13px;letter-spacing:0.06em;color:var(--teal);text-transform:uppercase}
  .row .rbody{color:var(--muted);font-size:15.5px;max-width:64ch}
  .row .rbody strong{color:var(--text);font-weight:600}
  /* callout */
  .callout{margin-top:40px;border:1px solid var(--line-strong);border-left:2px solid var(--amber);border-radius:14px;
    background:linear-gradient(180deg,rgba(244,196,107,0.05),transparent);padding:24px 26px}
  .callout .k{font-family:var(--mono);font-size:12px;letter-spacing:0.12em;text-transform:uppercase;color:var(--amber)}
  .callout p{color:var(--muted);margin-top:12px;font-size:15.5px;max-width:70ch}
  .callout p strong{color:var(--text);font-weight:600}
  /* mini waitlist strip on interior pages */
  .strip{margin:0 0 0;padding:0}
  .strip .cta-box{border-radius:22px}
"""

CSS = MASTER_CSS + EXTRA_CSS

LOGO = ('<svg class="logo" viewBox="0 0 32 32" fill="none" aria-hidden="true">'
        '<path d="M16 2 4 9v14l12 7 12-7V9L16 2Z" stroke="#4fd1c5" stroke-width="1.4" fill="rgba(79,209,197,0.06)"/>'
        '<path d="M16 8 10 11.5v7L16 22l6-3.5v-7L16 8Z" stroke="#a78bfa" stroke-width="1.3" fill="none"/>'
        '<circle cx="16" cy="15" r="2.1" fill="#4fd1c5"/></svg>')

NAV_ITEMS = [("builders.html", "Builders"),
             ("receivers.html", "Receivers"),
             ("how-it-works.html", "How it works"),
             ("programme.html", "Programme")]

def nav(active):
    links = ""
    for href, label in NAV_ITEMS:
        cls = ' class="active"' if href == active else ""
        links += f'<a href="{href}"{cls}>{label}</a>'
    return f'''<header>
  <div class="wrap nav">
    <a class="brand" href="index.html" aria-label="MeshKor home">
      {LOGO}<span>MeshKor</span><span class="pill">Preview</span>
    </a>
    <nav class="nav-links">
      {links}
      <a class="btn btn-primary" href="index.html#waitlist">Join the waitlist</a>
    </nav>
  </div>
</header>'''

FOOTER = f'''<footer>
  <div class="wrap">
    <div class="foot">
      <div>
        <a class="brand" href="index.html">{LOGO}<span>MeshKor</span></a>
        <p>The trust authority for AI agents. Issuer of the AIN under the Trusted Bot Programme.</p>
      </div>
      <div class="foot-links">
        <div class="foot-col">
          <b>Product</b>
          <a href="builders.html">For builders</a>
          <a href="receivers.html">For receivers</a>
          <a href="how-it-works.html">How it works</a>
          <a href="programme.html">Trusted Bot Programme</a>
        </div>
        <div class="foot-col">
          <b>Company</b>
          <a href="index.html#gap">Why now</a>
          <a href="index.html#waitlist">Early access</a>
          <a href="mailto:hello@meshkor.ai">Contact</a>
        </div>
      </div>
    </div>
    <div class="foot-base">
      <span>© 2026 MeshKor · meshkor.ai · Preview</span>
      <span>Prove what an agent is, and what it may reach.</span>
    </div>
  </div>
</footer>'''

WAITLIST_STRIP = '''<section class="cta strip" style="border-top:none">
    <div class="wrap">
      <div class="cta-box reveal">
        <span class="label" style="justify-content:center">Early access</span>
        <h2 style="margin-top:14px">Prove your agents are who they say they are.</h2>
        <p>MeshKor is in preview. Join the waitlist and we'll reach out as we open enrollment to the first builders.</p>
        <a class="btn btn-primary" href="index.html#waitlist" style="margin-top:26px">Join the waitlist &rarr;</a>
      </div>
    </div>
  </section>'''

REVEAL_JS = '''<script>
  (function(){var els=document.querySelectorAll('.reveal');
   if(!('IntersectionObserver' in window)){els.forEach(function(e){e.classList.add('in')});return;}
   var io=new IntersectionObserver(function(en){en.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);}})},{threshold:0.12,rootMargin:'0px 0px -8% 0px'});
   els.forEach(function(e){io.observe(e)});})();
</script>'''

def page(slug, title, desc, active, body):
    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>{title}</title>
<meta name="description" content="{desc}" />
<meta name="robots" content="noindex, nofollow" />
<meta property="og:title" content="{title}" />
<meta property="og:description" content="{desc}" />
<meta property="og:type" content="website" />
<meta property="og:url" content="https://meshkor.ai/{slug}" />
<style>{CSS}</style>
</head>
<body>
<div class="field" aria-hidden="true"></div>
{nav(active)}
<main id="top">
{body}
</main>
{FOOTER}
{REVEAL_JS}
</body>
</html>'''
    (ROOT / slug).write_text(html, encoding="utf-8")
    print("wrote", slug, f"({len(html)} bytes)")

def crumb(label):
    return f'<div class="crumb reveal"><a href="index.html">Home</a><span class="sep">/</span>{label}</div>'

def sec_head(label, h2, p, extra=""):
    return f'''<div class="sec-head reveal">
        <span class="label">{label}</span>
        <h2>{h2}</h2>
        <p>{p}</p>{extra}
      </div>'''

# ============================================================ BUILDERS
builders_body = f'''  <section class="page-hero">
    <div class="wrap">
      {crumb("Builders")}
      <span class="label reveal">For builders</span>
      <h1 class="reveal">Enroll your agents. Get AINs.</h1>
      <p class="lede reveal">Give every agent you run a provable identity and a history that can't be quietly rewritten, so it's trusted the moment it leaves your systems. Builders come first, because the need is already there.</p>
      <div class="hero-cta reveal"><a class="btn btn-primary" href="index.html#waitlist">Join the waitlist &rarr;</a><a class="btn btn-ghost" href="how-it-works.html">How it works</a></div>
    </div>
  </section>

  <section>
    <div class="wrap">
      {sec_head("Enrollment", "Easy to join, meaningful once joined.", "A bot joins through an automated check, so getting in is fast and cheap. Once in, it carries the full envelope. Easy to join so millions do it, meaningful once joined so receivers can rely on it.")}
      <div class="rows reveal">
        <div class="row"><div class="rlabel">The check</div><div class="rbody">A <strong>business identifier</strong> establishes the business behind the agent, and a <strong>domain-verified email</strong> ties the operator to it, with a light fallback for operators on free email domains. The assumption is simple: every agent, even one a person built, ultimately serves a business, so the party certified is a business and the person is its authorized operator.</div></div>
        <div class="row"><div class="rlabel">No human in the loop</div><div class="rbody">The normal path is fully automated, which is what keeps the cost per issuance well under a tenth of a cent. That's the number the whole volume model rests on. A small, risky slice can be flagged for heavier scrutiny while the majority runs near-free.</div></div>
        <div class="row"><div class="rlabel">What you don't hand over</div><div class="rbody">No sensitive personal identifiers to hold. The real-world identity is bound into the AIN <strong>by hash</strong>, never carried in the clear, so the credential proves the tie without becoming a liability to store.</div></div>
      </div>
    </div>
  </section>

  <section>
    <div class="wrap">
      {sec_head("The client", "Drop it onto an agent built anywhere.", "The trust layer doesn't care how your agent is built. The client is framework-neutral and stack-independent, so adoption is bottom-up: attach it, and the agent can present itself and prove its pedigree without a rebuild.")}
      <div class="cards three">
        <div class="card reveal"><h3>Any framework</h3><p>Attach with a decorator or a mixin, whichever fits your codebase. The same credential travels with the agent regardless of the stack underneath it.</p><div class="kv"># one drop-in, <span>any stack</span></div></div>
        <div class="card reveal" style="transition-delay:.06s"><h3>Single-pass proof</h3><p>Your agent presents a self-contained token and proves itself in one pass, with no round trips. That fits event-driven agents that spend most of their time asleep.</p><div class="kv"># async, <span>no round trips</span></div></div>
        <div class="card reveal" style="transition-delay:.12s"><h3>Carries the envelope</h3><p>Structured identity, a sealed birth record, a tamper-evident history, encryption, and a capability manifest, all traveling with the agent as one package.</p><div class="kv"># the whole <span>uniform</span>, not a badge</div></div>
      </div>
    </div>
  </section>

  <section id="pricing" class="anchor">
    <div class="wrap">
      {sec_head("Pricing", "Cheap per agent. Real over volume and years.", "The shape follows the token providers: very cheap per instance, priced to be a non-decision, with real money accumulating over volume and years of billing. Not free, because free trains an expectation that's hard to reverse. Verification is priced to disappear, issuance carries a small sliver, and the standing relationship, agents under management, is where the recurring revenue lives.")}
      <div class="tiers reveal">
        <div class="tier"><span class="tname">Entry</span><div class="price">Near free<small>get started</small></div><p>Bare identity for a small number of agents. Enough to prove an agent is who it says it is.</p><div class="cap">cap <b>low</b> · identity only</div></div>
        <div class="tier feature"><span class="tname">Builder</span><div class="price">Low hundreds<small>per month</small></div><p>A higher agent cap and the fuller envelope: behavioral monitoring and twin-backed recovery.</p><div class="cap">cap <b>higher</b> · full envelope</div></div>
        <div class="tier"><span class="tname">Scale</span><div class="price">Volume<small>large fleets</small></div><p>For large agent counts, adding full lifecycle management and compliance features.</p><div class="cap">cap <b>large</b> · lifecycle + compliance</div></div>
        <div class="tier"><span class="tname">Custom</span><div class="price">Let's talk<small>negotiated</small></div><p>For a few dozen customers each running millions of agents at deeply discounted slivers. Where the real revenue concentrates.</p><div class="cap">cap <b>millions</b> · negotiated</div></div>
      </div>
      <div class="callout reveal"><span class="k">The idea</span><p>The core credential stays cheap at every level, because <strong>ubiquity is the asset</strong>. Verification flows freely rather than being rationed, since a rationed check would undermine the product. Issuance is priced to drive adoption, not margin. The value builds in the standing relationship over time.</p></div>
    </div>
  </section>

  {WAITLIST_STRIP}'''

# ============================================================ RECEIVERS
receivers_body = f'''  <section class="page-hero">
    <div class="wrap">
      {crumb("Receivers")}
      <span class="label reveal" style="color:var(--violet)">For receivers</span>
      <h1 class="reveal">Validate incoming agents with one lookup.</h1>
      <p class="lede reveal">You accept transactions from agents you didn't build. When one shows up, confirm it's genuine and see exactly what it's permitted to reach, with a single check against the authority.</p>
      <div class="hero-cta reveal"><a class="btn btn-primary" href="index.html#waitlist">Talk to us &rarr;</a><a class="btn btn-ghost" href="programme.html">The trust ladder</a></div>
    </div>
  </section>

  <section>
    <div class="wrap">
      {sec_head("Validation", "A one-way lookup, not an integration.", "Builders enroll their agents; you check them. You never touch the builder's stack and they never touch yours. Both of you talk only to MeshKor, so trust has a single root instead of a web of private arrangements.")}
      <div class="rows reveal">
        <div class="row"><div class="rlabel">What you confirm</div><div class="rbody">That the agent's <strong>origin is authentic</strong> and its <strong>history is intact</strong>, in one pass, without walking its entire past. A constant-size summary keeps the check flat no matter how long the agent has been running.</div></div>
        <div class="row"><div class="rlabel">What you can see</div><div class="rbody">The agent's declared <strong>blast radius</strong> and capability manifest, so you know what it's allowed to reach before you act on anything it asks for. Identity and permission, in the same lookup.</div></div>
        <div class="row"><div class="rlabel">How far you trust it</div><div class="rbody">The <strong>trust ladder</strong> tells you whether an agent is merely identified, accountable with a tracked history and monitoring, or fully audited. You decide which rung you require for which action.</div></div>
      </div>
    </div>
  </section>

  <section>
    <div class="wrap">
      {sec_head("Why it turns", "The more certified agents in the wild, the riskier it is to ignore them.", "Volume on the builder side manufactures demand on the receiver side. As certified agents spread, accepting an uncertified stranger becomes the harder position to defend. The receiver pattern already exists in the world before a single standalone receiver is sold.")}
      <div class="cards two">
        <div class="card reveal"><div class="ico" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 3 4 6v6c0 4.5 3.2 7.7 8 9 4.8-1.3 8-4.5 8-9V6l-8-3Z" stroke="#a78bfa" stroke-width="1.5"/><path d="m8.5 12 2.4 2.4L15.8 9.6" stroke="#a78bfa" stroke-width="1.5"/></svg></div><h3>Authentication vs validation</h3><p>Two agents proving themselves to each other is a two-way handshake, authentication. You checking an incoming agent is a one-way lookup, validation. Both roll up under the Trusted Bot Programme; the precise terms are kept for engineering.</p></div>
        <div class="card reveal" style="transition-delay:.06s"><div class="ico" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="#a78bfa" stroke-width="1.5"/><path d="M12 7v5l3 2" stroke="#a78bfa" stroke-width="1.5"/></svg></div><h3>Nothing to build</h3><p>No integration with the builder's framework, no shared infrastructure, no standing arrangement. You query the authority and get a verdict you can act on.</p></div>
      </div>
    </div>
  </section>

  {WAITLIST_STRIP}'''

# ============================================================ HOW IT WORKS
# reuse the flow diagram from the home page (balanced extraction)
FLOW_SVG = extract_div(home, 'class="flow reveal"')

howitworks_body = f'''  <section class="page-hero">
    <div class="wrap">
      {crumb("How it works")}
      <span class="label reveal">How it works</span>
      <h1 class="reveal">Proof of origin, and a record of everything since.</h1>
      <p class="lede reveal">The pedigree is a sealed birth record plus a tamper-evident history chain. Birth alone would miss later tampering; history alone could be anchored to a forged origin. The point is the unbroken line from a verified origin through a verified history.</p>
    </div>
  </section>

  <section>
    <div class="wrap">
      {sec_head("The pedigree", "One credential, verified cheaply, at scale.", "Four interdependent mechanisms keep verification cheap no matter how much history an agent accumulates, and none of them stands without the others.")}
      {FLOW_SVG}
      <div class="cards three" style="margin-top:32px">
        <div class="card reveal"><h3>Constant-size head</h3><p>A running summary keeps verification flat regardless of history length. Whether an agent has ten events or a hundred thousand, the fast check costs the same.</p></div>
        <div class="card reveal" style="transition-delay:.06s"><h3>Tiered FAST / FULL</h3><p>A cheap FAST check serves the routine many; a deep FULL walk of the whole history is there for the rare few who need it. Most checks never pay the full cost.</p></div>
        <div class="card reveal" style="transition-delay:.12s"><h3>Cached, single-pass</h3><p>Cached trust removes repeated cost within a window, and verification is single-pass and asynchronous, with no round trips, so it fits agents that spend most of their time asleep.</p></div>
      </div>
    </div>
  </section>

  <section>
    <div class="wrap">
      {sec_head("The safety layers", "A genuine agent can still misbehave. These watch for that.", "Authenticity and conduct are different questions, so they're handled separately. Protection scales with irreversibility: reversible actions are automatic and fast, and the irreversible ones require the keys.")}
      <div class="rows reveal">
        <div class="row"><div class="rlabel">Behavioral monitoring</div><div class="rbody">Watches conduct separately from authenticity, because an agent that is genuinely who it claims to be can still drift or misbehave. This is the fuzzy, threshold-based signal.</div></div>
        <div class="row"><div class="rlabel">Manifest drift</div><div class="rbody">Any attempt outside the sealed manifest is a clean, <strong>binary</strong> divergence between what was permitted and what was tried, a far sharper halt signal than behavioral thresholds. Isolation is automatic and reversible.</div></div>
        <div class="row"><div class="rlabel">The encrypted twin</div><div class="rbody">A dormant, encrypted twin is the restoration source, hidden from the world but reachable by the hardware keys. It's what makes recovery from a bad state possible without trusting the live copy.</div></div>
        <div class="row"><div class="rlabel">The key quorum</div><div class="rbody">A threshold hardware-key quorum gates the three existential, irreversible actions, creating an agent, restoring from a twin, and destroying one, with the most catastrophic action requiring the largest quorum.</div></div>
      </div>
    </div>
  </section>

  <section>
    <div class="wrap">
      {sec_head("The bridge", "From provenance to enforcement.", "The birth record already carries the rules an agent was born with. The bridge activates that field so the rules do real work: a machine-readable manifest, a sandbox that enforces it, drift as a clean halt, and MeshKor as the credential root.")}
      <div class="cards three">
        <div class="card reveal"><div class="ico" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="4" y="4" width="16" height="16" rx="3" stroke="#4fd1c5" stroke-width="1.5"/><path d="M9 12h6M12 9v6" stroke="#4fd1c5" stroke-width="1.5"/></svg></div><h3>Capability manifest</h3><p>Allowed tools, allowed endpoints, credential scopes, and a declared blast radius, sealed into the signed birth. An agent can't widen its own reach later without breaking its own pedigree.</p></div>
        <div class="card reveal" style="transition-delay:.06s"><div class="ico" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 3 5 6v5c0 4 3 6.5 7 8 4-1.5 7-4 7-8V6l-7-3Z" stroke="#4fd1c5" stroke-width="1.5"/></svg></div><h3>Runtime sandbox</h3><p>Verifies the agent, loads its sealed manifest, and refuses anything outside it. Blocked attempts are recorded, not silently dropped.</p></div>
        <div class="card reveal" style="transition-delay:.12s"><div class="ico" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="8" cy="12" r="3" stroke="#4fd1c5" stroke-width="1.5"/><path d="M11 12h9M17 12v3" stroke="#4fd1c5" stroke-width="1.5"/></svg></div><h3>Credential root</h3><p>Short-lived, scoped tokens issued only against a passing verification and only for scopes already in the manifest. No standing secrets to steal, no reaching past the declared blast radius.</p></div>
      </div>
      <div class="callout reveal"><span class="k">The honest boundary</span><p>MeshKor is the policy and identity layer. It does not provide the physical kernel isolation that would stop two agents sharing a process at the infrastructure level; that belongs to whoever runs the compute. <strong>True defense in depth pairs MeshKor with that isolation layer</strong>, and we're clear about where the line sits.</p></div>
    </div>
  </section>

  {WAITLIST_STRIP}'''

# ============================================================ PROGRAMME
# reuse the ladder rungs from home (balanced extraction)
LADDER = extract_div(home, 'class="ladder"')

programme_body = f'''  <section class="page-hero">
    <div class="wrap">
      {crumb("Trusted Bot Programme")}
      <span class="label reveal">The Trusted Bot Programme</span>
      <h1 class="reveal">One authority. One credential. Three levels of assurance.</h1>
      <p class="lede reveal">A bot joins the programme by getting certified, and membership is not a name on a list. It's the full envelope traveling with the bot, and every verification traces back to a single authority.</p>
    </div>
  </section>

  <section>
    <div class="wrap">
      {sec_head("The AIN", "A passport for agents, structured like a UPC.", "The Agent Identification Number is readable so it can be checked at a glance, sealed into a signed birth record so it can't be forged, and it binds the real-world identity by hash rather than carrying personal data in the clear.")}
      <div class="cred reveal" style="max-width:560px">
        <div class="cred-inner">
          <div class="cred-glow" aria-hidden="true"></div>
          <div class="cred-head"><span class="who">Agent Identification Number</span><span class="chip">&#9679; Certified</span></div>
          <div class="ain"><span class="k">KMC</span>.<span class="t">CMP</span>.<span class="e">acme7f3a</span>.<span class="i">0001</span>.<span class="h">9a2f&hellip;c71b</span></div>
          <div class="ain-legend"><div><b>Root</b>MeshKor</div><div><b>Type</b>Company</div><div><b>Entity</b>Operator</div><div><b>Instance</b>Agent #</div><div><b>Real-ID</b>Hash</div></div>
          <div class="cred-foot"><span class="stat">Origin&nbsp; <b class="ok">&#10003; authentic</b></span><span class="stat">History&nbsp; <b class="ok">&#10003; intact</b></span><span class="stat">Manifest&nbsp; <b>read &middot; query</b></span></div>
        </div>
      </div>
    </div>
  </section>

  <section id="ladder" class="anchor">
    <div class="wrap">
      {sec_head("The trust ladder", "Identity is the base. Some receivers will want more.", "The base AIN certifies who stands behind an agent and that its history is intact. It doesn't claim the agent has been inspected. Each rung is worth more to the receivers who care most, and the rungs are kept distinct so a receiver can always tell which one they're looking at.")}
      {LADDER}
    </div>
  </section>

  <section>
    <div class="wrap">
      {sec_head("The audit", "The premium rung, for agents that can do real damage.", "The base AIN certifies identity and provenance, not capability or intent. It says a real party stands behind this agent and its history is intact. It does not say the agent has been inspected and provably does only what it claims. That deeper assurance is a cyber audit.")}
      <div class="rows reveal">
        <div class="row"><div class="rlabel">Kept separate</div><div class="rbody">The audit is deliberately distinct from the AIN, so a receiver can always tell whether a bot is merely <strong>identified</strong> or actually <strong>audited</strong>. Mixing them would blur exactly the distinction that matters.</div></div>
        <div class="row"><div class="rlabel">Scoped to the stakes</div><div class="rbody">What an audit certifies depends heavily on what the bot can affect, from answering questions to making commitments to moving money. It's offered as an optional premium service, performed by MeshKor to start, and priced to the stakes.</div></div>
        <div class="row"><div class="rlabel">Learned, not guessed</div><div class="rbody">The detailed definitions aren't written in stone yet, on purpose. The first few engagements will teach what an audit should certify, rather than committing to a rigid checklist before the practice exists.</div></div>
      </div>
    </div>
  </section>

  {WAITLIST_STRIP}'''

page("builders.html", "MeshKor for builders — enroll your agents, get AINs",
     "Give every agent you run a provable identity and a tamper-evident history. Enroll on any stack, attach a drop-in client, and get an AIN under the Trusted Bot Programme.",
     "builders.html", builders_body)
page("receivers.html", "MeshKor for receivers — validate incoming agents",
     "Confirm an incoming agent is genuine and see what it's permitted to reach, with one lookup against the authority. No integration with the builder's stack required.",
     "receivers.html", receivers_body)
page("how-it-works.html", "How MeshKor works — the pedigree, sandbox, and credential root",
     "The pedigree is a sealed birth record plus a tamper-evident history chain, verified cheaply at scale, with a capability manifest, runtime sandbox, and MeshKor as the credential root.",
     "how-it-works.html", howitworks_body)
page("programme.html", "The Trusted Bot Programme — the AIN and the trust ladder",
     "One authority, one credential, three levels of assurance: identified, accountable, and audited. The AIN is issued under the Trusted Bot Programme.",
     "programme.html", programme_body)
print("done")
